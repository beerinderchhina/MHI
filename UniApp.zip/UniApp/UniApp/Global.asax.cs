﻿using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace UniApp
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
