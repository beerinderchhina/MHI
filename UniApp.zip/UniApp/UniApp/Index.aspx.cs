﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UniApp
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDiagnosticExamSubmit_OnClick(object sender, EventArgs e)
        {
            
            //D

            lblDecisionSupportText.Text =
                "CT without contrast is not indicated initally [Grade B- moderate evidence] Includes situations where experience shows that the clinical problem usually resolves with time, and where deferring the study is suggested. CT is only indicated for patients with severe hemoptysis or other risk factors . (see Hemoptysis: smoker, high risk of malignancy, >40 yrs of recurrent). Radiation Dose (mSv): 5-10 Reference source:  Canadian Association of Radiologists Referral guidelines for Thoracic system)";

            txtDecisionSupportTitle.Text = "sunny";

        }
    }
}